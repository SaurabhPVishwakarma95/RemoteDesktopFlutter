import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class Viewer extends StatefulWidget {
  @override
  State<Viewer> createState() => _ViewerState();
}

class _ViewerState extends State<Viewer> {
  final _renderer = RTCVideoRenderer();
  RTCPeerConnection? _pc;

  final _ws = WebSocketChannel.connect(
    Uri.parse('ws://localhost:8080'),
  );

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _renderer.initialize();

    _pc = await createPeerConnection({
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'}
      ]
    });

    _pc!.onTrack = (e) {
      _renderer.srcObject = e.streams[0];
    };


    _ws.stream.listen((msg) async {
      final data = jsonDecode(msg);

      if (data['offer'] != null) {
        await _pc!.setRemoteDescription(
          RTCSessionDescription(data['offer']['sdp'], 'offer'),
        );

        final answer = await _pc!.createAnswer();
        await _pc!.setLocalDescription(answer);

        _ws.sink.add(jsonEncode({'answer': answer.toMap()}));
      } else if (data['candidate'] != null) {
        await _pc!.addCandidate(
          RTCIceCandidate(
            data['candidate']['candidate'],
            data['candidate']['sdpMid'],
            data['candidate']['sdpMLineIndex'],
          ),
        );
      }
    });
    _pc!.onIceCandidate = (c) {
      if (c != null) {
        _ws.sink.add(jsonEncode({'candidate': c.toMap()}));
      }
    };
  }

  @override
  void dispose() {
    _renderer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Remote Desktop Viewer")),
      body: RTCVideoView(_renderer),
    );
  }
}