import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class ScreenSender extends StatefulWidget {
  @override
  State<ScreenSender> createState() => _ScreenSenderState();
}

class _ScreenSenderState extends State<ScreenSender> {
  RTCPeerConnection? _pc;
  MediaStream? _stream;
  final _ws = WebSocketChannel.connect(
    Uri.parse('ws://localhost:8080'),
  );

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final config = {
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'}
      ]
    };

    _pc = await createPeerConnection(config);

    _pc!.onIceCandidate = (c) {
      if (c != null) {
        _ws.sink.add(jsonEncode({'candidate': c.toMap()}));
      }
    };

    _stream = await navigator.mediaDevices.getDisplayMedia({
      'video': true,
      'audio': false,
    });

    for (var track in _stream!.getTracks()) {
      _pc!.addTrack(track, _stream!);
    }

    _ws.stream.listen((msg) async {
      final data = jsonDecode(msg);
      if (data['answer'] != null) {
        await _pc!.setRemoteDescription(
          RTCSessionDescription(data['answer']['sdp'], 'answer'),
        );
      } else if (data['candidate'] != null) {
        await _pc!.addCandidate(
          RTCIceCandidate(
            data['candidate']['candidate'],
            data['candidate']['sdpMid'],
            data['candidate']['sdpMLineIndex'],
          ),
        );
      }
    });

    final offer = await _pc!.createOffer();
    await _pc!.setLocalDescription(offer);

    _ws.sink.add(jsonEncode({'offer': offer.toMap()}));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Screen Sender")),
      body: Center(child: Text("Sharing Screen...")),
    );
  }
}