import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import 'webrtc_service.dart';

class RemoteDesktopWidget extends StatefulWidget {
  final String wsUrl;
  final bool isHost;

  const RemoteDesktopWidget({
    super.key,
    required this.wsUrl,
    required this.isHost,
  });

  @override
  State<RemoteDesktopWidget> createState() => _RemoteDesktopWidgetState();
}

class _RemoteDesktopWidgetState extends State<RemoteDesktopWidget> {  
  final RTCVideoRenderer _renderer = RTCVideoRenderer();
  final WebRTCService _service = WebRTCService();

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await _service.initRenderer(_renderer);
    await _service.connect(widget.wsUrl, widget.isHost);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (d) {
        _service.sendControl({
          'type': 'mouse_move',
          'dx': d.delta.dx,
          'dy': d.delta.dy,
        });
      },
      onTap: () {
        _service.sendControl({'type': 'mouse_click'});
      },
      child: RTCVideoView(
        _renderer,
        objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain,
      ),
    );
  }

  @override
  void dispose() {
    _renderer.dispose();
    super.dispose();
  }
}
