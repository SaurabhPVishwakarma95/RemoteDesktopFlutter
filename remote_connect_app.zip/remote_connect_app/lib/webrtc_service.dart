import 'dart:convert';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

class WebRTCService {
  RTCPeerConnection? _pc;
  RTCVideoRenderer? renderer;
  RTCDataChannel? controlChannel;
  late WebSocketChannel socket;

  Future<void> initRenderer(RTCVideoRenderer r) async {
    renderer = r;
    await renderer!.initialize();
  }

  Future<void> connect(String wsUrl, bool isHost) async {
    socket = WebSocketChannel.connect(Uri.parse(wsUrl));

    _pc = await createPeerConnection({
      'iceServers': [
        {'urls': 'stun:stun.l.google.com:19302'}
      ]
    });

    _pc!.onTrack = (event) {
      renderer?.srcObject = event.streams.first;
    };

    _pc!.onIceCandidate = (candidate) {
      socket.sink.add(jsonEncode({
        'type': 'candidate',
        'data': candidate.toMap(),
      }));
    };

    socket.stream.listen((msg) async {
      print("Message: $msg");
      final data = jsonDecode(msg) ?? {"type": "candidate"};

      if (data['type'] == 'offer') {
        await _pc!.setRemoteDescription(
          RTCSessionDescription(data['sdp'], 'offer'),
        );
        final answer = await _pc!.createAnswer();
        await _pc!.setLocalDescription(answer);
        socket.sink.add(jsonEncode({
          'type': 'answer',
          'sdp': answer.sdp,
        }));
      }

      if (data['type'] == 'answer') {
        await _pc!.setRemoteDescription(
          RTCSessionDescription(data['sdp'], 'answer'),
        );
      }

      if (data['type'] == 'candidate') {
        await _pc!.addCandidate(
          RTCIceCandidate(
            data['data']['candidate'],
            data['data']['sdpMid'],
            data['data']['sdpMLineIndex'],
          ),
        );
      }
    });

    if (isHost) {
      await _startScreenShare();
      await _createOffer();
    } else {
      controlChannel = await _pc!.createDataChannel(
        'control',
        RTCDataChannelInit(),
      );
    }
  }

  Future<void> _startScreenShare() async {
    final stream =
        await navigator.mediaDevices.getDisplayMedia({'video': true});
    stream.getTracks().forEach((t) {
      _pc!.addTrack(t, stream);
    });
  }

  Future<void> _createOffer() async {
    final offer = await _pc!.createOffer();
    await _pc!.setLocalDescription(offer);
    socket.sink.add(jsonEncode({
      'type': 'offer',
      'sdp': offer.sdp,
    }));
  }

  void sendControl(Map<String, dynamic> data) {
    controlChannel?.send(
      RTCDataChannelMessage(jsonEncode(data)),
    );
  }
}
