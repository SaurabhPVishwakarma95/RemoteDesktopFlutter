package com.example.remote_connect_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
